<?php
/**
 * Plugin Name: Stagebook Slider
 * Description: Ersätter Slide Anything. Visar befintliga [slide-anything id="…"]-karuseller med samma HTML, klasser och karusell (Owl Carousel) som tidigare, utan att sidorna behöver ändras.
 * Version: 1.0.3
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Alexander Gerhard
 * License: GPL-2.0-or-later
 * Text Domain: stagebook-slider
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SBS_VERSION', '1.0.3' );
define( 'SBS_URL', plugin_dir_url( __FILE__ ) );

if ( is_admin() ) {
	require __DIR__ . '/includes/admin.php';
}

/**
 * Registrera shortcoden efter andra plugins, så att vår version alltid gäller.
 */
add_action( 'init', function () {
	remove_shortcode( 'slide-anything' );
	add_shortcode( 'slide-anything', 'sbs_render_slider' );
}, 20 );

/**
 * Samma filer som Slide Anything laddade: Owl Carousel + Slide Anythings tema-CSS.
 */
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'sbs-owl', SBS_URL . 'assets/owl-carousel/owl.carousel.css', array(), '2.3.4' );
	wp_register_style( 'sbs-owl-theme', SBS_URL . 'assets/owl-carousel/sa-owl-theme.css', array( 'sbs-owl' ), SBS_VERSION );
	wp_register_script( 'sbs-owl', SBS_URL . 'assets/owl-carousel/owl.carousel.min.js', array( 'jquery' ), '2.3.4', true );
	wp_register_script( 'sbs-slider', SBS_URL . 'assets/stagebook-slider.js', array( 'sbs-owl' ), SBS_VERSION, true );
} );

/**
 * Läs ett metavärde från Slide Anything-posten.
 */
function sbs_meta( $meta, $key, $default = '' ) {
	return ( isset( $meta[ $key ][0] ) && '' !== $meta[ $key ][0] ) ? $meta[ $key ][0] : $default;
}

/**
 * Shortcode: [slide-anything id="123"]
 * HTML:en följer Slide Anything (frontend.php) så att temats CSS träffar som förut.
 */
function sbs_render_slider( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'slide-anything' );
	$id   = absint( $atts['id'] );

	if ( ! $id || 'publish' !== get_post_status( $id ) || 'sa_slider' !== get_post_type( $id ) ) {
		return current_user_can( 'edit_posts' ) ? '<p class="sbs-error">Stagebook Slider: hittar ingen slider med id ' . esc_html( $atts['id'] ) . '.</p>' : '';
	}

	$meta       = get_metadata( 'post', $id );
	$num        = absint( sbs_meta( $meta, 'sa_num_slides', 0 ) );
	$shortcodes = '1' === sbs_meta( $meta, 'sa_shortcodes' );
	$css_id     = sanitize_html_class( sbs_meta( $meta, 'sa_css_id', 'slider_' . $id ) );

	// "Other settings": 7 = bildstorlek för bakgrunden, 8 = klass i stället för id på korten.
	$other       = explode( '|', sbs_meta( $meta, 'sa_other_settings' ) );
	$bg_size     = ! empty( $other[6] ) ? $other[6] : 'full';
	$no_slide_id = isset( $other[7] ) && '1' === $other[7];

	$slides = array();
	for ( $i = 1; $i <= $num; $i++ ) {
		$content = sbs_meta( $meta, 'sa_slide' . $i . '_content' );

		// Bild: nytt format "id~pos~size~repeat~color" eller äldre separata fält.
		$image_data = sbs_meta( $meta, 'sa_slide' . $i . '_image_data' );
		if ( '' !== $image_data ) {
			$parts = array_pad( explode( '~', $image_data ), 5, '' );
		} else {
			$parts = array(
				sbs_meta( $meta, 'sa_slide' . $i . '_image_id', 0 ),
				sbs_meta( $meta, 'sa_slide' . $i . '_image_pos' ),
				sbs_meta( $meta, 'sa_slide' . $i . '_image_size' ),
				sbs_meta( $meta, 'sa_slide' . $i . '_image_repeat' ),
				sbs_meta( $meta, 'sa_slide' . $i . '_image_color' ),
			);
		}

		$slides[] = array(
			'num'     => $i,
			'content' => $shortcodes ? do_shortcode( $content ) : $content,
			'image'   => absint( $parts[0] ),
			'pos'     => $parts[1],
			'size'    => $parts[2],
			'repeat'  => $parts[3],
			'color'   => $parts[4],
			'link'    => sbs_meta( $meta, 'sa_slide' . $i . '_link_url' ),
			'target'  => sbs_meta( $meta, 'sa_slide' . $i . '_link_target', '_self' ),
		);
	}

	if ( ! $slides ) {
		return '';
	}

	if ( '1' === sbs_meta( $meta, 'sa_random_order' ) ) {
		shuffle( $slides );
	} elseif ( '1' === sbs_meta( $meta, 'sa_reverse_order' ) ) {
		$slides = array_reverse( $slides );
	}

	// Inställningar till Owl Carousel – samma som Slide Anything skickade.
	$items = array();
	foreach ( array( 1 => 0, 2 => 480, 3 => 768, 4 => 980, 5 => 1200, 6 => 1500 ) as $n => $bp ) {
		$value = absint( sbs_meta( $meta, 'sa_items_width' . $n ) );
		if ( ! $value && 6 === $n ) {
			$value = absint( sbs_meta( $meta, 'sa_items_width5' ) );
		}
		$items[ $bp ] = array( 'items' => max( 1, $value ? $value : 1 ) );
	}
	$duration   = floatval( sbs_meta( $meta, 'sa_slide_duration', 0 ) ) * 1000;
	$transition = floatval( sbs_meta( $meta, 'sa_slide_transition', 0.3 ) ) * 1000;
	$slide_by   = sbs_meta( $meta, 'sa_slide_by', '1' );
	$pagination = '1' === sbs_meta( $meta, 'sa_pagination' );
	$config     = array(
		'responsive'            => $items,
		'autoplay'              => $duration > 0,
		'autoplayTimeout'       => $duration > 0 ? $duration : 5000,
		'autoplayHoverPause'    => $duration > 0 && '1' === sbs_meta( $meta, 'sa_stop_hover' ),
		'smartSpeed'            => $transition,
		'fluidSpeed'            => $transition,
		'autoplaySpeed'         => $transition,
		'navSpeed'              => $transition,
		'dotsSpeed'             => $transition,
		// Karusellen går alltid runt (Daniel 24.10).
		'loop'                  => true,
		'nav'                   => '1' === sbs_meta( $meta, 'sa_nav_arrows' ),
		'navText'               => array( 'Previous', 'Next' ),
		'dots'                  => $pagination,
		'responsiveRefreshRate' => 200,
		'slideBy'               => '0' === $slide_by ? 'page' : max( 1, absint( $slide_by ) ),
		'mergeFit'              => true,
		'autoHeight'            => '1' === sbs_meta( $meta, 'sa_auto_height' ),
		'mouseDrag'             => '1' === sbs_meta( $meta, 'sa_mouse_drag' ),
		'touchDrag'             => '1' === sbs_meta( $meta, 'sa_touch_drag' ),
	);
	if ( '1' === sbs_meta( $meta, 'sa_dot_per_slide' ) ) {
		$config['dotsEach'] = 1;
	}

	wp_enqueue_style( 'sbs-owl-theme' );
	wp_enqueue_script( 'sbs-slider' );

	// Ram och luft runt karusellen.
	$wrapper_style = sprintf(
		'background:%s; border:solid %spx %s; border-radius:%spx; padding:%spx %spx %spx %spx;',
		sbs_meta( $meta, 'sa_background_color' ),
		sbs_meta( $meta, 'sa_border_width', '0' ),
		sbs_meta( $meta, 'sa_border_color' ),
		sbs_meta( $meta, 'sa_border_radius', '0' ),
		sbs_meta( $meta, 'sa_wrapper_padd_top', '0' ),
		sbs_meta( $meta, 'sa_wrapper_padd_right', '0' ),
		sbs_meta( $meta, 'sa_wrapper_padd_bottom', '0' ),
		sbs_meta( $meta, 'sa_wrapper_padd_left', '0' )
	);
	$icons_color   = 'black' === sbs_meta( $meta, 'sa_slide_icons_color' ) ? 'black' : 'white';
	$classes       = $pagination ? 'owl-pagination-true' : '';
	if ( '1' === sbs_meta( $meta, 'sa_autohide_arrows' ) ) {
		$classes .= ' autohide-arrows';
	}

	$padding_tb   = sbs_meta( $meta, 'sa_slide_padding_tb', '0' );
	$padding_lr   = sbs_meta( $meta, 'sa_slide_padding_lr', '0' );
	$margin_lr    = sbs_meta( $meta, 'sa_slide_margin_lr', '0' );
	$min_height   = sbs_meta( $meta, 'sa_slide_min_height_perc' );
	$vert_center  = '1' === sbs_meta( $meta, 'sa_vert_center' );
	$icons_full   = '1' === sbs_meta( $meta, 'sa_slide_icons_fullslide' );
	$icons_always = '1' === sbs_meta( $meta, 'sa_slide_icons_visible' );
	$icons_style  = sbs_icons_style( sbs_meta( $meta, 'sa_slide_icons_location' ) );

	$out  = '<div class="' . esc_attr( $icons_color ) . '" style="' . esc_attr( $wrapper_style ) . '">' . "\n";
	$out .= '<div id="' . esc_attr( $css_id ) . '" class="owl-carousel sa_owl_theme ' . esc_attr( trim( $classes ) ) . '" data-slider-id="' . esc_attr( $css_id ) . '" data-sbs="' . esc_attr( wp_json_encode( $config ) ) . '" style="visibility:hidden;">' . "\n";

	foreach ( $slides as $slide ) {
		$style = 'padding:' . $padding_tb . '% ' . $padding_lr . '%; margin:0px ' . $margin_lr . '%; ';
		if ( $slide['image'] ) {
			$src = wp_get_attachment_image_src( $slide['image'], $bg_size );
			if ( $src ) {
				$style .= 'background-image:url("' . esc_url( $src[0] ) . '"); background-position:' . $slide['pos'] . '; background-size:' . $slide['size'] . '; background-repeat:' . $slide['repeat'] . '; ';
			}
		}
		if ( $slide['color'] && 'rgba(0,0,0,0)' !== $slide['color'] ) {
			$style .= 'background-color:' . $slide['color'] . '; ';
		}
		if ( false !== strpos( $min_height, 'px' ) ) {
			$style .= 'min-height:' . $min_height . '; ';
		}

		$slide_id  = $css_id . '_slide' . sprintf( '%02d', $slide['num'] );
		$container = 'sa_hover_container' . ( $vert_center ? ' sa_vert_center_wrap' : '' );
		if ( $no_slide_id ) {
			$out .= '<div class="' . esc_attr( $slide_id . ' ' . $container ) . '" style="' . esc_attr( $style ) . '">';
		} else {
			$out .= '<div id="' . esc_attr( $slide_id ) . '" class="' . esc_attr( $container ) . '" style="' . esc_attr( $style ) . '">';
		}

		// Länkknapp, eller hela kortet som länk.
		if ( $slide['link'] ) {
			$target = '_blank' === $slide['target'] ? '_blank' : '_self';
			$link   = '<a class="sa_slide_link_icon" href="' . esc_url( $slide['link'] ) . '" target="' . esc_attr( $target ) . '"' . ( '_blank' === $target ? ' rel="noopener"' : '' ) . ' title="" aria-label=""></a>';
			if ( $icons_full ) {
				$out .= '<div class="sa_hover_fullslide">' . $link . "</div>\n";
			} else {
				$out .= '<div class="sa_hover_buttons' . ( $icons_always ? ' always_visible' : '' ) . '" style="' . esc_attr( $icons_style ) . '">' . $link . "</div>\n";
			}
		}

		// Innehållet skrivs ut som det sparats, precis som i Slide Anything.
		$content = $slide['content'];
		if ( $vert_center ) {
			$content = '<div class="sa_vert_center">' . $content . '</div>';
		}
		$out .= $content . "</div>\n";
	}

	$out .= "</div>\n</div>\n";
	return $out;
}

/**
 * Var länkknappen ligger på kortet (Slide Anything: "slide icons location").
 */
function sbs_icons_style( $location ) {
	switch ( $location ) {
		case 'Top Left':
			return 'top:0px; left:0px; margin:0px;';
		case 'Top Center':
			return 'top:0px; left:50%; margin-left:-20px;';
		case 'Top Right':
			return 'top:0px; right:0px; margin:0px;';
		case 'Bottom Left':
			return 'bottom:0px; left:0px; margin:0px;';
		case 'Bottom Center':
			return 'bottom:0px; left:50%; margin-left:-20px;';
		case 'Bottom Right':
			return 'bottom:0px; right:0px; margin:0px;';
		default:
			return 'top:50%; left:50%; margin-top:-20px; margin-left:-20px;';
	}
}
