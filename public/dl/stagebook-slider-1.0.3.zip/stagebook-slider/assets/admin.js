/* Stagebook Slider – lägg till, flytta, kopiera och ta bort slides i adminpanelen */
jQuery(function ($) {
	var $list = $('.sbs-slides');
	if (!$list.length) {
		return;
	}

	function renumber() {
		$list.children('.sbs-slide').each(function (i) {
			$(this).find('.sbs-slide-num').text('Slide ' + (i + 1));
		});
	}

	$('.sbs-add').on('click', function () {
		$list.append($('#sbs-slide-template').html());
		renumber();
		$list.children('.sbs-slide').last().find('textarea').trigger('focus');
	});

	$list.on('click', '.sbs-up', function () {
		var $li = $(this).closest('.sbs-slide');
		$li.prev('.sbs-slide').before($li);
		renumber();
	});

	$list.on('click', '.sbs-down', function () {
		var $li = $(this).closest('.sbs-slide');
		$li.next('.sbs-slide').after($li);
		renumber();
	});

	$list.on('click', '.sbs-copy', function () {
		var $li = $(this).closest('.sbs-slide');
		var $copy = $li.clone();
		$copy.find('textarea').val($li.find('textarea').val());
		$li.after($copy);
		renumber();
	});

	$list.on('click', '.sbs-remove', function () {
		$(this).closest('.sbs-slide').remove();
		renumber();
	});

	$list.on('change', '.sbs-blank', function () {
		$(this).closest('.sbs-link').find('[name="sbs_target[]"]').val(this.checked ? '_blank' : '_self');
	});

	// Förhandsvisning uppdateras medan man skriver.
	$list.on('input', 'textarea', function () {
		$(this).closest('.sbs-slide').find('.sbs-slide-preview').html($('<div>').html(this.value).find('script,style,iframe').remove().end().html());
	});

	// Välj bild i mediabiblioteket och lägg in den där markören står.
	$list.on('click', '.sbs-media', function () {
		var $area = $(this).siblings('textarea');
		var frame = wp.media({ title: 'Välj bild', button: { text: 'Lägg in' }, library: { type: 'image' }, multiple: false });
		frame.on('select', function () {
			var img = frame.state().get('selection').first().toJSON();
			var url = img.sizes && img.sizes.large ? img.sizes.large.url : img.url;
			var tag = $('<img>').attr({ src: url, alt: img.alt || '', 'class': 'wp-image-' + img.id }).prop('outerHTML');
			var el = $area[0];
			var pos = el.selectionStart || 0;
			el.value = el.value.slice(0, pos) + tag + el.value.slice(el.selectionEnd || pos);
			$area.trigger('input');
		});
		frame.open();
	});

	renumber();
});
