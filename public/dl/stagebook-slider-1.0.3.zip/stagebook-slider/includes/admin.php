<?php
/**
 * Stagebook Slider – redigera karuseller i adminpanelen (ersätter Slide Anythings admin).
 * Bara användare som får redigera sidor kommer åt den, och varje sparning kontrolleras med nonce.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Karusellerna ligger kvar som "sa_slider"-poster – visa dem i menyn.
 */
add_action( 'init', function () {
	if ( post_type_exists( 'sa_slider' ) ) {
		return;
	}
	register_post_type( 'sa_slider', array(
		'labels'          => array(
			'name'          => 'Karuseller',
			'singular_name' => 'Karusell',
			'add_new'       => 'Ny karusell',
			'add_new_item'  => 'Ny karusell',
			'edit_item'     => 'Redigera karusell',
			'all_items'     => 'Alla karuseller',
			'not_found'     => 'Inga karuseller',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'show_in_rest'    => false,
		'menu_icon'       => 'dashicons-images-alt2',
		'supports'        => array( 'title' ),
		'capability_type' => 'page',
		'map_meta_cap'    => true,
	) );
} );

add_action( 'add_meta_boxes_sa_slider', function () {
	add_meta_box( 'sbs-slides', 'Slides', 'sbs_slides_box', 'sa_slider', 'normal', 'high' );
	add_meta_box( 'sbs-shortcode', 'Shortcode', 'sbs_shortcode_box', 'sa_slider', 'side' );
} );

function sbs_shortcode_box( $post ) {
	echo '<input type="text" readonly class="widefat" onfocus="this.select()" value="' . esc_attr( '[slide-anything id="' . $post->ID . '"]' ) . '">';
}

/**
 * Lista med slides: innehåll (HTML), länk, flytta, kopiera, ta bort.
 */
function sbs_slides_box( $post ) {
	wp_nonce_field( 'sbs_save_slides', 'sbs_nonce' );

	$num    = absint( get_post_meta( $post->ID, 'sa_num_slides', true ) );
	$slides = array();
	for ( $i = 1; $i <= $num; $i++ ) {
		$slides[] = array(
			'content' => (string) get_post_meta( $post->ID, 'sa_slide' . $i . '_content', true ),
			'link'    => (string) get_post_meta( $post->ID, 'sa_slide' . $i . '_link_url', true ),
			'target'  => (string) get_post_meta( $post->ID, 'sa_slide' . $i . '_link_target', true ),
			'image'   => (string) get_post_meta( $post->ID, 'sa_slide' . $i . '_image_data', true ),
		);
	}
	if ( ! $slides ) {
		$slides[] = array( 'content' => '', 'link' => '', 'target' => '_self', 'image' => '' );
	}

	echo '<ol class="sbs-slides">';
	foreach ( $slides as $slide ) {
		sbs_slide_row( $slide );
	}
	echo '</ol>';
	echo '<p><button type="button" class="button button-primary sbs-add">Lägg till slide</button></p>';

	// Mall för nya slides.
	echo '<script type="text/html" id="sbs-slide-template">';
	sbs_slide_row( array( 'content' => '', 'link' => '', 'target' => '_self', 'image' => '' ) );
	echo '</script>';
}

function sbs_slide_row( $slide ) {
	?>
	<li class="sbs-slide">
		<div class="sbs-slide-head">
			<strong class="sbs-slide-num"></strong>
			<span class="sbs-slide-tools">
				<button type="button" class="button sbs-up" aria-label="Flytta upp">↑</button>
				<button type="button" class="button sbs-down" aria-label="Flytta ner">↓</button>
				<button type="button" class="button sbs-copy">Kopiera</button>
				<button type="button" class="button sbs-remove">Ta bort</button>
			</span>
		</div>
		<div class="sbs-slide-preview"><?php echo wp_kses_post( $slide['content'] ); ?></div>
		<p>
			<textarea name="sbs_content[]" rows="5" class="widefat code"><?php echo esc_textarea( $slide['content'] ); ?></textarea>
			<button type="button" class="button sbs-media">Lägg in bild</button>
		</p>
		<p class="sbs-link">
			<input type="url" name="sbs_link[]" class="regular-text" placeholder="Länk (https://…)" value="<?php echo esc_attr( $slide['link'] ); ?>">
			<label><input type="checkbox" class="sbs-blank" <?php checked( '_blank', $slide['target'] ); ?>> Nytt fönster</label>
			<input type="hidden" name="sbs_target[]" value="<?php echo esc_attr( '_blank' === $slide['target'] ? '_blank' : '_self' ); ?>">
			<input type="hidden" name="sbs_image[]" value="<?php echo esc_attr( $slide['image'] ); ?>">
		</p>
	</li>
	<?php
}

/**
 * Spara slides i samma metafält som Slide Anything använde, så att frontenden är oförändrad.
 */
add_action( 'save_post_sa_slider', function ( $post_id ) {
	if ( ! isset( $_POST['sbs_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['sbs_nonce'] ), 'sbs_save_slides' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$contents = isset( $_POST['sbs_content'] ) ? (array) wp_unslash( $_POST['sbs_content'] ) : array();
	$links    = isset( $_POST['sbs_link'] ) ? (array) wp_unslash( $_POST['sbs_link'] ) : array();
	$targets  = isset( $_POST['sbs_target'] ) ? (array) wp_unslash( $_POST['sbs_target'] ) : array();
	$images   = isset( $_POST['sbs_image'] ) ? (array) wp_unslash( $_POST['sbs_image'] ) : array();
	$raw_html = current_user_can( 'unfiltered_html' );

	$slides = array();
	foreach ( $contents as $k => $content ) {
		$content = (string) $content;
		$link    = isset( $links[ $k ] ) ? esc_url_raw( trim( $links[ $k ] ) ) : '';
		if ( '' === trim( $content ) && '' === $link ) {
			continue;
		}
		$image = isset( $images[ $k ] ) ? sanitize_text_field( $images[ $k ] ) : '';
		$slides[] = array(
			'content' => $raw_html ? $content : wp_kses_post( $content ),
			'link'    => $link,
			'target'  => ( isset( $targets[ $k ] ) && '_blank' === $targets[ $k ] ) ? '_blank' : '_self',
			'image'   => preg_match( '/^\d*(~[^~<>"]*){4}$/', $image ) ? $image : '',
		);
	}

	// Rensa gamla slide-fält, skriv sedan de nya i ordning.
	$old = absint( get_post_meta( $post_id, 'sa_num_slides', true ) );
	for ( $i = 1; $i <= max( $old, count( $slides ) ); $i++ ) {
		foreach ( array( 'content', 'link_url', 'link_target', 'image_data', 'image_id', 'image_pos', 'image_size', 'image_repeat', 'image_color', 'popup_type' ) as $field ) {
			delete_post_meta( $post_id, 'sa_slide' . $i . '_' . $field );
		}
	}
	foreach ( $slides as $k => $slide ) {
		$n = $k + 1;
		update_post_meta( $post_id, 'sa_slide' . $n . '_content', wp_slash( $slide['content'] ) );
		update_post_meta( $post_id, 'sa_slide' . $n . '_link_url', $slide['link'] );
		update_post_meta( $post_id, 'sa_slide' . $n . '_link_target', $slide['target'] );
		if ( '' !== $slide['image'] ) {
			update_post_meta( $post_id, 'sa_slide' . $n . '_image_data', $slide['image'] );
		}
	}
	update_post_meta( $post_id, 'sa_num_slides', count( $slides ) );

	// Ny karusell: samma grundinställningar som de befintliga.
	if ( ! $old && '' === get_post_meta( $post_id, 'sa_items_width1', true ) ) {
		foreach ( array( 1, 1, 2, 3, 4, 4 ) as $k => $items ) {
			update_post_meta( $post_id, 'sa_items_width' . ( $k + 1 ), $items );
		}
		update_post_meta( $post_id, 'sa_css_id', 'slider_' . $post_id );
		update_post_meta( $post_id, 'sa_nav_arrows', '1' );
		update_post_meta( $post_id, 'sa_pagination', '1' );
		update_post_meta( $post_id, 'sa_slide_by', '0' );
		update_post_meta( $post_id, 'sa_mouse_drag', '1' );
		update_post_meta( $post_id, 'sa_touch_drag', '1' );
	}
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	if ( ! $screen || 'sa_slider' !== $screen->post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'sbs-admin', SBS_URL . 'assets/admin.css', array(), SBS_VERSION );
	wp_enqueue_script( 'sbs-admin', SBS_URL . 'assets/admin.js', array( 'jquery' ), SBS_VERSION, true );
} );
