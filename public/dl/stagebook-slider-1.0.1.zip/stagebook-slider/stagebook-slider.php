<?php
/**
 * Plugin Name: Stagebook Slider
 * Description: Ersätter Slide Anything. Visar befintliga [slide-anything id="…"]-karuseller med Swiper, utan att sidorna behöver ändras.
 * Version: 1.0.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Alexander Gerhard
 * License: GPL-2.0-or-later
 * Text Domain: stagebook-slider
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SBS_VERSION', '1.0.1' );
define( 'SBS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Registrera shortcoden efter andra plugins, så att vår version alltid gäller.
 */
add_action( 'init', function () {
	remove_shortcode( 'slide-anything' );
	add_shortcode( 'slide-anything', 'sbs_render_slider' );
}, 20 );

add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'sbs-swiper', SBS_URL . 'assets/swiper-bundle.min.css', array(), '11.2.10' );
	wp_register_style( 'sbs-slider', SBS_URL . 'assets/stagebook-slider.css', array( 'sbs-swiper' ), SBS_VERSION );
	wp_register_script( 'sbs-swiper', SBS_URL . 'assets/swiper-bundle.min.js', array(), '11.2.10', true );
	wp_register_script( 'sbs-slider', SBS_URL . 'assets/stagebook-slider.js', array( 'sbs-swiper' ), SBS_VERSION, true );
} );

/**
 * Läs ett metavärde från Slide Anything-posten.
 */
function sbs_meta( $meta, $key, $default = '' ) {
	return ( isset( $meta[ $key ][0] ) && '' !== $meta[ $key ][0] ) ? $meta[ $key ][0] : $default;
}

/**
 * Shortcode: [slide-anything id="123"]
 */
function sbs_render_slider( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'slide-anything' );
	$id   = absint( $atts['id'] );

	if ( ! $id || 'publish' !== get_post_status( $id ) || 'sa_slider' !== get_post_type( $id ) ) {
		return current_user_can( 'edit_posts' ) ? '<p class="sbs-error">Stagebook Slider: hittar ingen slider med id ' . esc_html( $atts['id'] ) . '.</p>' : '';
	}

	$meta       = get_metadata( 'post', $id );
	$num        = absint( sbs_meta( $meta, 'sa_num_slides', 0 ) );
	$shortcodes = '1' === sbs_meta( $meta, 'sa_shortcodes' );
	$slides     = array();

	for ( $i = 1; $i <= $num; $i++ ) {
		$content = sbs_meta( $meta, 'sa_slide' . $i . '_content' );

		// Bild: nytt format "id~pos~size~repeat~color" eller äldre separata fält.
		$image_id   = 0;
		$image_data = sbs_meta( $meta, 'sa_slide' . $i . '_image_data' );
		if ( '' !== $image_data ) {
			$parts    = explode( '~', $image_data );
			$image_id = absint( $parts[0] );
		} else {
			$image_id = absint( sbs_meta( $meta, 'sa_slide' . $i . '_image_id', 0 ) );
		}
		if ( 99999999 === $image_id ) {
			$image_id = 0;
		}

		if ( '' === trim( $content ) && ! $image_id ) {
			continue;
		}

		$slides[] = array(
			'content' => $shortcodes ? do_shortcode( $content ) : $content,
			'image'   => $image_id,
			'link'    => sbs_meta( $meta, 'sa_slide' . $i . '_link_url' ),
			'target'  => sbs_meta( $meta, 'sa_slide' . $i . '_link_target', '_self' ),
		);
	}

	if ( ! $slides ) {
		return '';
	}

	if ( '1' === sbs_meta( $meta, 'sa_random_order' ) ) {
		shuffle( $slides );
	} elseif ( '1' === sbs_meta( $meta, 'sa_reverse_order' ) ) {
		$slides = array_reverse( $slides );
	}

	// Antal kort per skärmbredd (samma brytpunkter som Slide Anything).
	$items = array();
	foreach ( array( 1 => 0, 2 => 480, 3 => 768, 4 => 980, 5 => 1200, 6 => 1500 ) as $n => $bp ) {
		$default        = array( 1 => 1, 2 => 1, 3 => 2, 4 => 3, 5 => 4, 6 => 4 )[ $n ];
		$value          = absint( sbs_meta( $meta, 'sa_items_width' . $n, $default ) );
		$items[ $bp ]   = max( 1, $value ? $value : $default );
	}

	$config = array(
		'breakpoints' => $items,
		'loop'        => '1' === sbs_meta( $meta, 'sa_loop_slider', '1' ),
		'autoplay'    => (int) round( floatval( sbs_meta( $meta, 'sa_slide_duration', 0 ) ) * 1000 ),
		'pauseHover'  => '1' === sbs_meta( $meta, 'sa_stop_hover', '1' ),
		'speed'       => absint( sbs_meta( $meta, 'sa_slide_transition', 300 ) ),
		'slideByPage' => '0' === sbs_meta( $meta, 'sa_slide_by', '1' ),
		'arrows'      => '1' === sbs_meta( $meta, 'sa_nav_arrows', '1' ),
		'dots'        => '1' === sbs_meta( $meta, 'sa_pagination', '1' ),
	);

	wp_enqueue_style( 'sbs-slider' );
	wp_enqueue_script( 'sbs-slider' );

	$css_id = sanitize_html_class( sbs_meta( $meta, 'sa_css_id', 'slider_' . $id ) );

	ob_start();
	?>
	<div class="sbs" id="<?php echo esc_attr( $css_id ); ?>" data-sbs="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
		<div class="swiper sbs__swiper">
			<div class="swiper-wrapper">
				<?php foreach ( $slides as $slide ) : ?>
					<div class="swiper-slide sbs__slide">
						<div class="sbs__card">
							<?php
							// Bild överst om den inte redan finns i texten.
							if ( $slide['image'] && false === stripos( $slide['content'], '<img' ) ) {
								echo wp_get_attachment_image( $slide['image'], 'medium_large', false, array( 'class' => 'sbs__img', 'loading' => 'lazy' ) );
							}
							echo wp_kses_post( wpautop( $slide['content'] ) );
							?>
							<?php if ( $slide['link'] ) : ?>
								<a class="sbs__link" href="<?php echo esc_url( $slide['link'] ); ?>" target="<?php echo esc_attr( '_blank' === $slide['target'] ? '_blank' : '_self' ); ?>"<?php echo '_blank' === $slide['target'] ? ' rel="noopener"' : ''; ?> aria-hidden="true" tabindex="-1"></a>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php if ( $config['arrows'] ) : ?>
			<button type="button" class="sbs__nav sbs__nav--prev" aria-label="Föregående"></button>
			<button type="button" class="sbs__nav sbs__nav--next" aria-label="Nästa"></button>
		<?php endif; ?>
		<?php if ( $config['dots'] ) : ?>
			<div class="sbs__dots"></div>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
