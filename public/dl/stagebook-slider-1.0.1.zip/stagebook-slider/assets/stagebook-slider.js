/* Stagebook Slider – startar Swiper för varje [slide-anything]-karusell */
(function () {
	function init(el) {
		var cfg = {};
		try {
			cfg = JSON.parse(el.getAttribute('data-sbs')) || {};
		} catch (e) {}

		var gap = parseInt(getComputedStyle(el).getPropertyValue('--sbs-gap'), 10) || 24;
		var breakpoints = {};
		var bps = cfg.breakpoints || { 0: 1, 768: 2, 1200: 4 };
		Object.keys(bps).forEach(function (bp) {
			var n = bps[bp];
			breakpoints[bp] = {
				slidesPerView: n,
				slidesPerGroup: cfg.slideByPage ? n : 1,
				spaceBetween: n > 1 ? gap : 0
			};
		});

		var wrapper = el.querySelector('.swiper-wrapper');
		var originals = Array.prototype.slice.call(wrapper.querySelectorAll('.swiper-slide'));
		var count = originals.length;
		var maxPerView = Math.max.apply(null, Object.keys(bps).map(function (k) { return bps[k]; }));
		var maxGroup = cfg.slideByPage ? maxPerView : 1;

		// Karusellen går alltid runt (Daniel 24.10). Swiper behöver minst
		// "synliga + ett steg" kort för att loopa – annars kopieras korten.
		var loop = count > 1;
		var cloned = false;
		if (loop && count < maxPerView + maxGroup) {
			while (wrapper.children.length < maxPerView + maxGroup) {
				originals.forEach(function (s) {
					var c = s.cloneNode(true);
					c.setAttribute('aria-hidden', 'true');
					wrapper.appendChild(c);
				});
			}
			cloned = true;
		}

		var opts = {
			breakpoints: breakpoints,
			speed: cfg.speed || 300,
			loop: loop,
			watchOverflow: true,
			a11y: { prevSlideMessage: 'Föregående', nextSlideMessage: 'Nästa', paginationBulletMessage: 'Gå till {{index}}' }
		};

		if (cfg.autoplay > 0) {
			opts.autoplay = { delay: cfg.autoplay, pauseOnMouseEnter: !!cfg.pauseHover, disableOnInteraction: false };
		}
		if (cfg.arrows) {
			opts.navigation = { prevEl: el.querySelector('.sbs__nav--prev'), nextEl: el.querySelector('.sbs__nav--next') };
		}
		var dots = cfg.dots ? el.querySelector('.sbs__dots') : null;
		if (dots && !cloned) {
			opts.pagination = { el: dots, clickable: true };
		}

		var swiper = new Swiper(el.querySelector('.sbs__swiper'), opts);

		// Med kopierade kort: en punkt per riktigt kort.
		if (dots && cloned) {
			dots.classList.add('swiper-pagination-bullets', 'swiper-pagination-horizontal');
			for (var i = 0; i < count; i++) {
				var b = document.createElement('span');
				b.className = 'swiper-pagination-bullet';
				b.setAttribute('role', 'button');
				b.setAttribute('tabindex', '0');
				b.setAttribute('aria-label', 'Gå till ' + (i + 1));
				(function (n) {
					b.addEventListener('click', function () { swiper.slideToLoop(n); });
				})(i);
				dots.appendChild(b);
			}
			var mark = function () {
				var active = swiper.realIndex % count;
				Array.prototype.forEach.call(dots.children, function (d, n) {
					d.classList.toggle('swiper-pagination-bullet-active', n === active);
				});
			};
			swiper.on('realIndexChange', mark);
			mark();
		}
	}

	function start() {
		if (typeof Swiper === 'undefined') {
			return;
		}
		document.querySelectorAll('.sbs[data-sbs]').forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', start);
	} else {
		start();
	}
})();
