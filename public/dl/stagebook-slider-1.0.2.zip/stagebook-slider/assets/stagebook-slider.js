/* Stagebook Slider – startar Owl Carousel för varje [slide-anything]-karusell, som Slide Anything gjorde */
jQuery(function ($) {
	$('.owl-carousel[data-sbs]').each(function () {
		var $el = $(this);
		var cfg = {};
		try {
			cfg = JSON.parse($el.attr('data-sbs')) || {};
		} catch (e) {}

		$el.owlCarousel(cfg);
		$el.css('visibility', 'visible');
	});
});
